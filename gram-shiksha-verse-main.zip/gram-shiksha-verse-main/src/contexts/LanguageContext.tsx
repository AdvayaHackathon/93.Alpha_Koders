import React, { createContext, useState, useContext, ReactNode } from 'react';

type LanguageContextType = {
  language: string;
  setLanguage: (language: string) => void;
  t: (key: string) => string;
};

const LanguageContext = createContext<LanguageContextType | undefined>(undefined);

interface LanguageProviderProps {
  children: ReactNode;
}

// Translations
const translations: Record<string, Record<string, string>> = {
  en: {
    welcome: 'Welcome to',
    selectLanguage: 'Select your preferred language',
    continue: 'Continue',
    dashboard: 'Dashboard',
    resumeClass: 'Resume Class',
    test: 'Test & Quiz',
    studentReport: 'Student Report',
    revisionClass: 'Revision Class',
    videoUpload: 'Upload Video',
    resumeClassDesc: 'Start or continue a class lecture',
    testDesc: 'Conduct tests and quizzes',
    studentReportDesc: 'View student performance reports',
    revisionClassDesc: 'Access revision materials for students',
    videoUploadDesc: 'Upload new educational videos',
    selectGrade: 'Select Grade',
    selectSubject: 'Select Subject',
    selectTopic: 'Select Topic',
    startClass: 'Start Class',
    uploadVideo: 'Upload Video',
    dragDrop: 'Drag and drop video files or',
    browse: 'Browse',
    videoTitle: 'Video Title',
    videoDescription: 'Video Description',
    grade: 'Grade',
    subject: 'Subject',
    topic: 'Topic',
    submit: 'Submit',
  },
  hi: {
    welcome: 'में आपका स्वागत है',
    selectLanguage: 'अपनी पसंदीदा भाषा चुनें',
    continue: 'जारी रखें',
    dashboard: 'डैशबोर्ड',
    resumeClass: 'कक्षा जारी रखें',
    test: 'परीक्षा और प्रश्नोत्तरी',
    studentReport: 'छात्र रिपोर्ट',
    revisionClass: 'दोहराई कक्षा',
    videoUpload: 'वीडियो अपलोड करें',
    resumeClassDesc: 'कक्षा व्याख्यान शुरू या जारी रखें',
    testDesc: 'परीक्षा और प्रश्नोत्तरी आयोजित करें',
    studentReportDesc: 'छात्र प्रदर्शन रिपोर्ट देखें',
    revisionClassDesc: 'छात्रों के लिए दोहराई सामग्री का उपयोग करें',
    videoUploadDesc: 'नई शैक्षिक वीडियो अपलोड करें',
    selectGrade: 'कक्षा चुनें',
    selectSubject: 'विषय चुनें',
    selectTopic: 'टॉपिक चुनें',
    startClass: 'कक्षा शुरू करें',
    uploadVideo: 'वीडियो अपलोड करें',
    dragDrop: 'वीडियो फ़ाइलें खींचें और छोड़ें या',
    browse: 'ब्राउज़ करें',
    videoTitle: 'वीडियो शीर्षक',
    videoDescription: 'वीडियो विवरण',
    grade: 'कक्षा',
    subject: 'विषय',
    topic: 'टॉपिक',
    submit: 'जमा करें',
  },
  kn: {
    welcome: 'ಗೆ ಸುಸ್ವಾಗತ',
    selectLanguage: 'ನಿಮ್ಮ ಆದ್ಯತೆಯ ಭಾಷೆಯನ್ನು ಆಯ್ಕೆಮಾಡಿ',
    continue: 'ಮುಂದುವರಿಸಿ',
    dashboard: 'ಡ್ಯಾಶ್‌ಬೋರ್ಡ್',
    resumeClass: 'ತರಗತಿಯನ್ನು ಮುಂದುವರಿಸಿ',
    test: 'ಪರೀಕ್ಷೆ ಮತ್ತು ಕ್ವಿಜ್',
    studentReport: 'ವಿ��್ಯಾರ್ಥಿ ವರದಿ',
    revisionClass: 'ಪರಿಶೀಲನಾ ತರಗತಿ',
    videoUpload: 'ವೀಡಿಯೊ ಅಪ್‌ಲೋಡ್ ಮಾಡಿ',
    resumeClassDesc: 'ತರಗತಿ ಉಪನ್ಯಾಸವನ್ನು ಪ್ರಾರಂಭಿಸಿ ಅಥವಾ ಮುಂದುವರಿಸಿ',
    testDesc: 'ಪರೀಕ್ಷೆಗಳು ಮತ್ತು ಕ್ವಿಜ್‌ಗಳನ್ನು ನಡೆಸಿ',
    studentReportDesc: 'ವಿದ್ಯಾರ್ಥಿ ಕಾರ್ಯಕ್ಷಮತೆ ವರದಿಗಳನ್ನು ವೀಕ್ಷಿಸಿ',
    revisionClassDesc: 'ವಿದ್ಯಾರ್ಥಿಗಳಿಗೆ ಪರಿಶೀಲನಾ ಸಾಮಗ್ರಿಗಳನ್ನು ಪ್ರವೇಶಿಸಿ',
    videoUploadDesc: 'ಹೊಸ ಶೈಕ್ಷಣಿಕ ವೀಡಿಯೊಗಳನ್ನು ಅಪ್‌ಲೋಡ್ ಮಾಡಿ',
    selectGrade: 'ತರಗತಿ ಆಯ್ಕೆಮಾಡಿ',
    selectSubject: 'ವಿಷಯ ಆಯ್ಕೆಮಾಡಿ',
    selectTopic: 'ವಿಷಯ ಆಯ್ಕೆಮಾಡಿ',
    startClass: 'ತರಗತಿ ಪ್ರಾರಂಭಿಸಿ',
    uploadVideo: 'ವೀಡಿಯೊ ಅಪ್‌ಲೋಡ್ ಮಾಡಿ',
    dragDrop: 'ವೀಡಿಯೊ ಫೈಲ್‌ಗಳನ್ನು ಎಳೆದು ಬಿಡಿ ಅಥವಾ',
    browse: 'ಬ್ರೌಸ್ ಮಾಡಿ',
    videoTitle: 'ವೀಡಿಯೊ ಶೀರ್ಷಿಕೆ',
    videoDescription: 'ವೀಡಿಯೊ ವಿವರಣೆ',
    grade: 'ತರಗತಿ',
    subject: 'ವಿಷಯ',
    topic: 'ವಿಷಯ',
    submit: 'ಸಲ್ಲಿಸಿ',
  },
  bn: {
    welcome: 'এ আপনাকে স্বাগতম',
    selectLanguage: 'আপনার পছন্দের ভাষা নির্বাচন করুন',
    continue: 'চালিয়ে যান',
    dashboard: 'ড্যাশবোর্ড',
    resumeClass: 'ক্লাস চালিয়ে যান',
    test: 'পরীক্ষা ও কুইজ',
    studentReport: 'ছাত্র রিপোর্ট',
    revisionClass: 'পুনরালোচনা ক্লাস',
    videoUpload: 'ভিডিও আপলোড করুন',
    resumeClassDesc: 'ক্লাস লেকচার শুরু বা চালিয়ে যান',
    testDesc: 'পরীক্ষা ও কুইজ পরিচালনা করুন',
    studentReportDesc: 'ছাত্র পারফরম্যান্স রিপোর্ট দেখুন',
    revisionClassDesc: 'ছাত্রদের জন্য পুনরালোচনা উপকরণ অ্যাক্সেস করুন',
    videoUploadDesc: 'নতুন শিক্ষামূলক ভিডিও আপলোড করুন',
    selectGrade: 'গ্রেড নির্বাচন করুন',
    selectSubject: 'বিষয় নির্বাচন করুন',
    selectTopic: 'টপিক নির্বাচন করুন',
    startClass: 'ক্লাস শুরু করুন',
    uploadVideo: 'ভিডিও আপলোড করুন',
    dragDrop: 'ভিডিও ফাইল টেনে আনুন অথবা',
    browse: 'ব্রাউজ করুন',
    videoTitle: 'ভিডিও শিরোনাম',
    videoDescription: 'ভিডিও বিবরণ',
    grade: 'গ্রেড',
    subject: 'বিষয়',
    topic: 'টপিক',
    submit: 'জমা দিন',
  },
};

export const LanguageProvider: React.FC<LanguageProviderProps> = ({ children }) => {
  const [language, setLanguage] = useState('en');

  const t = (key: string): string => {
    if (translations[language] && translations[language][key]) {
      return translations[language][key];
    }
    return translations.en[key] || key;
  };

  return (
    <LanguageContext.Provider value={{ language, setLanguage, t }}>
      {children}
    </LanguageContext.Provider>
  );
};

export const useLanguage = () => {
  const context = useContext(LanguageContext);
  if (context === undefined) {
    throw new Error('useLanguage must be used within a LanguageProvider');
  }
  return context;
};
