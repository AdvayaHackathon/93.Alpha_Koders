
import { Link, useLocation } from 'react-router-dom';
import { 
  BookOpen, 
  ClipboardList, 
  Users, 
  BookUp, 
  Home, 
  Upload,
  GraduationCap
} from 'lucide-react';

const Sidebar = () => {
  const location = useLocation();
  const currentPath = location.pathname;

  const menuItems = [
    { path: '/dashboard', icon: <Home size={22} />, label: 'Dashboard' },
    { path: '/resume-class', icon: <BookOpen size={22} />, label: 'Resume Class' },
    { path: '/test', icon: <ClipboardList size={22} />, label: 'Test & Quiz' },
    { path: '/student-report', icon: <Users size={22} />, label: 'Student Report' },
    { path: '/revision-class', icon: <BookUp size={22} />, label: 'Revision Class' },
    { path: '/video-upload', icon: <Upload size={22} />, label: 'Upload Video' },
  ];

  return (
    <div className="fixed top-0 left-0 h-full w-64 bg-eduverse-primary text-white shadow-lg">
      <div className="p-4 border-b border-eduverse-secondary">
        <div className="flex items-center gap-2">
          <GraduationCap size={28} className="text-eduverse-accent" />
          <h1 className="text-xl font-bold">EduVerse</h1>
        </div>
        <p className="text-sm text-eduverse-accent mt-1">Educational Platform</p>
      </div>
      <nav className="mt-6">
        <ul className="space-y-2 px-2">
          {menuItems.map((item) => (
            <li key={item.path}>
              <Link
                to={item.path}
                className={`flex items-center gap-3 p-3 rounded-lg transition-colors ${
                  currentPath === item.path
                    ? 'bg-eduverse-secondary text-white'
                    : 'text-eduverse-light hover:bg-eduverse-secondary/50'
                }`}
              >
                {item.icon}
                <span>{item.label}</span>
              </Link>
            </li>
          ))}
        </ul>
      </nav>
    </div>
  );
};

export default Sidebar;
