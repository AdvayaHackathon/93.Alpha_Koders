
import React from 'react';
import { Link } from 'react-router-dom';
import { LucideIcon } from 'lucide-react';

interface DashboardCardProps {
  title: string;
  description: string;
  icon: LucideIcon;
  to: string;
  color: string;
}

const DashboardCard: React.FC<DashboardCardProps> = ({
  title,
  description,
  icon: Icon,
  to,
  color,
}) => {
  return (
    <Link to={to} className="block w-full">
      <div 
        className={`dashboard-card bg-${color}-50 border-2 border-${color}-200`}
        style={{ minHeight: '200px' }}
      >
        <div className={`p-3 rounded-full bg-${color}-100 mb-4`}>
          <Icon className={`text-${color}-700`} size={32} />
        </div>
        <h3 className="text-xl font-semibold mb-2 text-center">{title}</h3>
        <p className="text-gray-600 text-center">{description}</p>
      </div>
    </Link>
  );
};

export default DashboardCard;
