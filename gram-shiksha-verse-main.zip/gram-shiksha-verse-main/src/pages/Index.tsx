
import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { GraduationCap } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import LanguageSelector from '@/components/LanguageSelector';
import { LanguageProvider, useLanguage } from '@/contexts/LanguageContext';

const WelcomePage = () => {
  const { language, setLanguage, t } = useLanguage();
  const navigate = useNavigate();
  const [selectedLanguage, setSelectedLanguage] = useState(language);

  const handleContinue = () => {
    setLanguage(selectedLanguage);
    navigate('/dashboard');
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-b from-green-50 to-green-100">
      <Card className="w-full max-w-md shadow-lg animate-fade-in">
        <CardContent className="p-8">
          <div className="flex flex-col items-center space-y-6">
            <div className="flex items-center justify-center w-16 h-16 rounded-full bg-eduverse-primary">
              <GraduationCap size={32} className="text-white" />
            </div>
            
            <div className="text-center">
              <h1 className="text-2xl font-bold text-eduverse-primary mb-2">
                {t('welcome')} EduVerse
              </h1>
              <p className="text-gray-600">
                {t('selectLanguage')}
              </p>
            </div>
            
            <div className="w-full py-4">
              <LanguageSelector 
                selectedLanguage={selectedLanguage}
                setSelectedLanguage={setSelectedLanguage}
              />
            </div>
            
            <Button 
              className="w-full bg-eduverse-primary hover:bg-eduverse-primary/90"
              onClick={handleContinue}
            >
              {t('continue')}
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

const Index = () => {
  return (
    <LanguageProvider>
      <WelcomePage />
    </LanguageProvider>
  );
};

export default Index;
