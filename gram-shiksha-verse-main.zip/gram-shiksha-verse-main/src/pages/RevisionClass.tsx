
import React, { useState } from 'react';
import { 
  Card, 
  CardContent, 
  CardDescription, 
  CardHeader, 
  CardTitle 
} from "@/components/ui/card";
import { 
  Tabs, 
  TabsContent, 
  TabsList, 
  TabsTrigger 
} from "@/components/ui/tabs";
import { PlayCircle, FileText, BookOpen } from 'lucide-react';
import { useLanguage } from '@/contexts/LanguageContext';

const RevisionClass = () => {
  const { t } = useLanguage();
  const [selectedVideo, setSelectedVideo] = useState<string | null>(null);

  // Mock revision videos data
  const revisionVideos = [
    { 
      id: '1', 
      title: 'Class 5 - Addition and Subtraction', 
      subject: 'Math',
      duration: '18:45',
      thumbnail: 'math-thumbnail.jpg',
      summary: 'This video covers the basics of addition and subtraction for Class 5 students. It includes practice problems and step-by-step solutions for common problem types.',
      notes: [
        'Addition: Combining two or more numbers to find their sum',
        'Subtraction: Finding the difference between two numbers',
        'Place values must be aligned properly',
        'For borrowing in subtraction, borrow 10 from the digit in the next place value',
        'Check subtraction answers by adding the difference to the subtrahend'
      ]
    },
    { 
      id: '2', 
      title: 'Class 6 - Plant Cell Structure', 
      subject: 'Science',
      duration: '22:30',
      thumbnail: 'science-thumbnail.jpg',
      summary: 'This video explains the structure and function of plant cells for Class 6 students. It covers all the major organelles and their roles in plant cell functions.',
      notes: [
        'Plant cells have a rigid cell wall made of cellulose',
        'Chloroplasts contain chlorophyll for photosynthesis',
        'Large central vacuole stores water and nutrients',
        'Cell membrane controls what enters and exits the cell',
        'Mitochondria provide energy through cellular respiration'
      ]
    },
    { 
      id: '3', 
      title: 'Class 7 - Parts of Speech', 
      subject: 'English',
      duration: '15:20',
      thumbnail: 'english-thumbnail.jpg',
      summary: 'This revision video covers the eight parts of speech in English grammar for Class 7 students, with examples and practice exercises.',
      notes: [
        'Nouns: Name of person, place, thing, or idea',
        'Verbs: Action or state of being',
        'Adjectives: Describe nouns or pronouns',
        'Adverbs: Modify verbs, adjectives, or other adverbs',
        'Pronouns: Replace nouns',
        'Prepositions: Show relationship between words',
        'Conjunctions: Connect words, phrases, or clauses',
        'Interjections: Express strong emotion'
      ]
    },
    { 
      id: '4', 
      title: 'Class 8 - India\'s Freedom Struggle', 
      subject: 'Social Studies',
      duration: '25:15',
      thumbnail: 'social-thumbnail.jpg',
      summary: 'This video provides a comprehensive overview of India\'s freedom struggle for Class 8 students, covering major events, movements, and leaders.',
      notes: [
        'First War of Independence: 1857',
        'Formation of Indian National Congress: 1885',
        'Partition of Bengal and Swadeshi Movement: 1905',
        'Non-Cooperation Movement: 1920-22',
        'Civil Disobedience Movement: 1930',
        'Quit India Movement: 1942',
        'Independence and Partition: 1947'
      ]
    },
  ];

  return (
    <div className="container mx-auto py-8">
      <h1 className="text-3xl font-bold mb-8 text-eduverse-primary">{t('revisionClass')}</h1>

      {selectedVideo ? (
        <div className="w-full max-w-4xl mx-auto animate-fade-in">
          <button 
            onClick={() => setSelectedVideo(null)}
            className="mb-4 text-eduverse-primary hover:text-eduverse-secondary flex items-center"
          >
            ← Back to videos
          </button>
          
          {revisionVideos.filter(video => video.id === selectedVideo).map(video => (
            <div key={video.id}>
              <div className="aspect-video bg-gray-200 rounded-lg flex items-center justify-center mb-6">
                <div className="text-center">
                  <PlayCircle size={48} className="mx-auto mb-2 text-eduverse-primary opacity-70" />
                  <p className="text-lg text-gray-600">
                    {video.title}
                  </p>
                  <p className="text-sm text-gray-500 mt-2">
                    (Video would play here in the actual application)
                  </p>
                </div>
              </div>
              
              <Tabs defaultValue="summary">
                <TabsList className="grid w-full grid-cols-2">
                  <TabsTrigger value="summary">Summary</TabsTrigger>
                  <TabsTrigger value="notes">Notes</TabsTrigger>
                </TabsList>
                
                <TabsContent value="summary" className="mt-4">
                  <Card>
                    <CardHeader>
                      <CardTitle className="flex items-center">
                        <FileText className="mr-2" size={18} />
                        Video Summary
                      </CardTitle>
                      <CardDescription>{video.subject} | {video.duration}</CardDescription>
                    </CardHeader>
                    <CardContent>
                      <p className="text-gray-700">{video.summary}</p>
                    </CardContent>
                  </Card>
                </TabsContent>
                
                <TabsContent value="notes" className="mt-4">
                  <Card>
                    <CardHeader>
                      <CardTitle className="flex items-center">
                        <BookOpen className="mr-2" size={18} />
                        Key Notes
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <ul className="list-disc pl-5 space-y-2">
                        {video.notes.map((note, index) => (
                          <li key={index} className="text-gray-700">{note}</li>
                        ))}
                      </ul>
                    </CardContent>
                  </Card>
                </TabsContent>
              </Tabs>
            </div>
          ))}
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-2 gap-6">
          {revisionVideos.map(video => (
            <Card 
              key={video.id} 
              className="overflow-hidden hover:shadow-md transition-shadow cursor-pointer"
              onClick={() => setSelectedVideo(video.id)}
            >
              <div className="aspect-video bg-gray-200 flex items-center justify-center relative group">
                <PlayCircle 
                  size={40} 
                  className="text-white opacity-80 group-hover:opacity-100 group-hover:scale-110 transition-all" 
                />
                <div className="absolute bottom-2 right-2 bg-black/70 text-white text-xs px-2 py-1 rounded">
                  {video.duration}
                </div>
              </div>
              <CardHeader className="pb-2">
                <CardTitle className="text-lg">{video.title}</CardTitle>
                <CardDescription>{video.subject}</CardDescription>
              </CardHeader>
              <CardContent>
                <p className="text-gray-700 text-sm line-clamp-2">
                  {video.summary}
                </p>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
};

export default RevisionClass;
