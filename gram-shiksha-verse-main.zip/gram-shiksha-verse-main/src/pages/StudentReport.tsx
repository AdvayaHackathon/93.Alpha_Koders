
import React, { useState } from 'react';
import { 
  Card, 
  CardContent, 
  CardDescription, 
  CardHeader, 
  CardTitle 
} from "@/components/ui/card";
import { 
  Select, 
  SelectContent, 
  SelectItem, 
  SelectTrigger, 
  SelectValue 
} from "@/components/ui/select";
import { 
  AlertTriangle,
  CheckCircle,
  BarChart
} from 'lucide-react';
import { useLanguage } from '@/contexts/LanguageContext';

const StudentReport = () => {
  const { t } = useLanguage();
  const [selectedStudent, setSelectedStudent] = useState('');

  // Mock student data
  const students = [
    { id: '1', name: 'Rahul Kumar' },
    { id: '2', name: 'Priya Sharma' },
    { id: '3', name: 'Amit Singh' },
    { id: '4', name: 'Neha Patel' },
  ];

  // Mock report data
  const reportData = {
    '1': {
      name: 'Rahul Kumar',
      grade: '6',
      overallScore: 78,
      subjects: [
        { name: 'Math', score: 85, strength: true },
        { name: 'Science', score: 72, strength: false },
        { name: 'English', score: 68, strength: false },
        { name: 'Social Studies', score: 90, strength: true },
      ],
      weakAreas: ['English Grammar', 'Chemical Equations'],
      improvementAreas: ['Reading Comprehension', 'Problem Solving'],
    },
    '2': {
      name: 'Priya Sharma',
      grade: '7',
      overallScore: 82,
      subjects: [
        { name: 'Math', score: 75, strength: false },
        { name: 'Science', score: 88, strength: true },
        { name: 'English', score: 90, strength: true },
        { name: 'Social Studies', score: 77, strength: false },
      ],
      weakAreas: ['Algebra', 'Geography'],
      improvementAreas: ['Mathematical Concepts', 'Map Reading'],
    },
    '3': {
      name: 'Amit Singh',
      grade: '8',
      overallScore: 65,
      subjects: [
        { name: 'Math', score: 60, strength: false },
        { name: 'Science', score: 65, strength: false },
        { name: 'English', score: 78, strength: true },
        { name: 'Social Studies', score: 59, strength: false },
      ],
      weakAreas: ['Geometry', 'Science Concepts', 'History'],
      improvementAreas: ['Conceptual Understanding', 'Regular Practice'],
    },
    '4': {
      name: 'Neha Patel',
      grade: '5',
      overallScore: 92,
      subjects: [
        { name: 'Math', score: 95, strength: true },
        { name: 'Science', score: 90, strength: true },
        { name: 'English', score: 88, strength: true },
        { name: 'Social Studies', score: 94, strength: true },
      ],
      weakAreas: ['Vocabulary'],
      improvementAreas: ['Advanced Concepts'],
    },
  };

  const selectedStudentData = selectedStudent ? reportData[selectedStudent as keyof typeof reportData] : null;

  const getScoreColor = (score: number) => {
    if (score >= 90) return 'text-green-600';
    if (score >= 75) return 'text-blue-600';
    if (score >= 60) return 'text-amber-600';
    return 'text-red-600';
  };

  return (
    <div className="container mx-auto py-8">
      <h1 className="text-3xl font-bold mb-8 text-eduverse-primary">{t('studentReport')}</h1>

      <div className="w-full max-w-md mb-8 mx-auto">
        <Select value={selectedStudent} onValueChange={setSelectedStudent}>
          <SelectTrigger>
            <SelectValue placeholder="Select a student" />
          </SelectTrigger>
          <SelectContent>
            {students.map((student) => (
              <SelectItem key={student.id} value={student.id}>
                {student.name}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      {selectedStudentData && (
        <div className="space-y-6 animate-fade-in">
          <Card className="shadow-md">
            <CardHeader>
              <CardTitle className="flex items-center">
                <span>{selectedStudentData.name}</span>
                <span className="ml-2 text-sm text-gray-500">
                  (Grade {selectedStudentData.grade})
                </span>
              </CardTitle>
              <CardDescription>Overall performance analysis</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="flex items-center justify-center mb-6">
                <div className="w-32 h-32 rounded-full flex items-center justify-center border-8 border-eduverse-secondary">
                  <div className="text-center">
                    <div className={`text-3xl font-bold ${getScoreColor(selectedStudentData.overallScore)}`}>
                      {selectedStudentData.overallScore}%
                    </div>
                    <div className="text-sm text-gray-500">Overall</div>
                  </div>
                </div>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {selectedStudentData.subjects.map((subject, index) => (
                  <div 
                    key={index} 
                    className="flex items-center justify-between p-3 rounded-lg border"
                  >
                    <div>
                      <div className="font-medium">{subject.name}</div>
                      <div className={getScoreColor(subject.score)}>{subject.score}%</div>
                    </div>
                    {subject.strength ? (
                      <CheckCircle className="text-green-500" size={20} />
                    ) : (
                      <BarChart className="text-amber-500" size={20} />
                    )}
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Card className="shadow-md">
              <CardHeader>
                <CardTitle className="flex items-center">
                  <AlertTriangle className="mr-2 text-amber-500" size={20} />
                  Areas Needing Improvement
                </CardTitle>
              </CardHeader>
              <CardContent>
                <ul className="list-disc pl-5 space-y-2">
                  {selectedStudentData.weakAreas.map((area, index) => (
                    <li key={index} className="text-gray-700">{area}</li>
                  ))}
                </ul>
              </CardContent>
            </Card>

            <Card className="shadow-md">
              <CardHeader>
                <CardTitle className="flex items-center">
                  <CheckCircle className="mr-2 text-green-500" size={20} />
                  Recommended Focus Areas
                </CardTitle>
              </CardHeader>
              <CardContent>
                <ul className="list-disc pl-5 space-y-2">
                  {selectedStudentData.improvementAreas.map((area, index) => (
                    <li key={index} className="text-gray-700">{area}</li>
                  ))}
                </ul>
              </CardContent>
            </Card>
          </div>
        </div>
      )}
    </div>
  );
};

export default StudentReport;
