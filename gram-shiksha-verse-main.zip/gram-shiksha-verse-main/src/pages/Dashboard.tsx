
import React from 'react';
import { 
  BookOpen, 
  ClipboardList, 
  Users, 
  BookUp, 
  Upload 
} from 'lucide-react';
import DashboardCard from '@/components/DashboardCard';
import { useLanguage } from '@/contexts/LanguageContext';

const Dashboard = () => {
  const { t } = useLanguage();

  const dashboardItems = [
    { 
      title: t('resumeClass'), 
      description: t('resumeClassDesc'), 
      icon: BookOpen, 
      to: '/resume-class',
      color: 'green'
    },
    { 
      title: t('test'), 
      description: t('testDesc'), 
      icon: ClipboardList, 
      to: '/test',
      color: 'blue'
    },
    { 
      title: t('studentReport'), 
      description: t('studentReportDesc'), 
      icon: Users, 
      to: '/student-report',
      color: 'amber'
    },
    { 
      title: t('revisionClass'), 
      description: t('revisionClassDesc'), 
      icon: BookUp, 
      to: '/revision-class',
      color: 'indigo'
    },
    { 
      title: t('videoUpload'), 
      description: t('videoUploadDesc'), 
      icon: Upload, 
      to: '/video-upload',
      color: 'red'
    }
  ];

  return (
    <div className="container mx-auto py-8">
      <h1 className="text-3xl font-bold mb-8 text-eduverse-primary">{t('dashboard')}</h1>
      
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {dashboardItems.map((item, index) => (
          <DashboardCard
            key={index}
            title={item.title}
            description={item.description}
            icon={item.icon}
            to={item.to}
            color={item.color}
          />
        ))}
      </div>
    </div>
  );
};

export default Dashboard;
