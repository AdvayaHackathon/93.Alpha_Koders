
import React from 'react';
import { 
  Tabs, 
  TabsContent, 
  TabsList, 
  TabsTrigger 
} from "@/components/ui/tabs";
import { 
  Card, 
  CardContent, 
  CardDescription, 
  CardHeader, 
  CardTitle 
} from "@/components/ui/card";
import { useLanguage } from '@/contexts/LanguageContext';

const Test = () => {
  const { t } = useLanguage();

  // Mock data for tests and quizzes
  const tests = [
    { id: 1, title: 'Class 5 Math - Addition', date: '2025-04-15', status: 'Available' },
    { id: 2, title: 'Class 6 Science - Plants', date: '2025-04-16', status: 'Available' },
    { id: 3, title: 'Class 7 English - Grammar', date: '2025-04-14', status: 'Completed' },
    { id: 4, title: 'Class 8 Social Studies - History', date: '2025-04-13', status: 'Completed' },
  ];

  const quizzes = [
    { id: 1, title: 'Weekly Quiz - Class 5', date: '2025-04-19', status: 'Upcoming' },
    { id: 2, title: 'Weekly Quiz - Class 6', date: '2025-04-12', status: 'Available' },
    { id: 3, title: 'Weekly Quiz - Class 7', date: '2025-04-05', status: 'Completed' },
    { id: 4, title: 'Weekly Quiz - Class 8', date: '2025-03-29', status: 'Completed' },
  ];

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'Available':
        return 'bg-green-100 text-green-800';
      case 'Upcoming':
        return 'bg-blue-100 text-blue-800';
      case 'Completed':
        return 'bg-gray-100 text-gray-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  return (
    <div className="container mx-auto py-8">
      <h1 className="text-3xl font-bold mb-8 text-eduverse-primary">{t('test')}</h1>

      <Tabs defaultValue="tests" className="w-full">
        <TabsList className="grid w-full grid-cols-2 mb-8">
          <TabsTrigger value="tests">Topic Tests</TabsTrigger>
          <TabsTrigger value="quizzes">Weekly Quizzes</TabsTrigger>
        </TabsList>
        
        <TabsContent value="tests">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {tests.map((test) => (
              <Card key={test.id} className="shadow-sm hover:shadow-md transition-shadow">
                <CardHeader className="pb-2">
                  <CardTitle>{test.title}</CardTitle>
                  <CardDescription>Date: {test.date}</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="flex justify-between items-center">
                    <span 
                      className={`px-2 py-1 rounded-full text-xs font-medium ${getStatusColor(test.status)}`}
                    >
                      {test.status}
                    </span>
                    
                    {test.status === 'Available' && (
                      <button className="text-eduverse-primary hover:text-eduverse-secondary font-medium text-sm">
                        Start Test
                      </button>
                    )}
                    
                    {test.status === 'Completed' && (
                      <button className="text-eduverse-primary hover:text-eduverse-secondary font-medium text-sm">
                        View Results
                      </button>
                    )}
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>
        
        <TabsContent value="quizzes">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {quizzes.map((quiz) => (
              <Card key={quiz.id} className="shadow-sm hover:shadow-md transition-shadow">
                <CardHeader className="pb-2">
                  <CardTitle>{quiz.title}</CardTitle>
                  <CardDescription>Date: {quiz.date}</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="flex justify-between items-center">
                    <span 
                      className={`px-2 py-1 rounded-full text-xs font-medium ${getStatusColor(quiz.status)}`}
                    >
                      {quiz.status}
                    </span>
                    
                    {quiz.status === 'Available' && (
                      <button className="text-eduverse-primary hover:text-eduverse-secondary font-medium text-sm">
                        Start Quiz
                      </button>
                    )}
                    
                    {quiz.status === 'Completed' && (
                      <button className="text-eduverse-primary hover:text-eduverse-secondary font-medium text-sm">
                        View Results
                      </button>
                    )}
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default Test;
