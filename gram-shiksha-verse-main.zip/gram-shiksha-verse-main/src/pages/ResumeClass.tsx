import React, { useState, useEffect } from 'react';
import { 
  Select, 
  SelectContent, 
  SelectItem, 
  SelectTrigger, 
  SelectValue 
} from "@/components/ui/select";
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { PlayCircle } from 'lucide-react';
import { useToast } from '@/components/ui/use-toast';
import { useLanguage } from '@/contexts/LanguageContext';
import { supabase } from '@/integrations/supabase/client';
import { Tables } from '@/integrations/supabase/types';

const ResumeClass = () => {
  const { t } = useLanguage();
  const { toast } = useToast();
  const [grade, setGrade] = useState('');
  const [subject, setSubject] = useState('');
  const [topic, setTopic] = useState('');
  const [videoStarted, setVideoStarted] = useState(false);
  const [video, setVideo] = useState<Tables<'videos'> | null>(null);
  const [loading, setLoading] = useState(false);

  // Updated mock data to include Computer Network for Grade 8
  const grades = ['5', '6', '7', '8', '9', '10'];
  const subjects = {
    '5': ['Math', 'Science', 'English', 'Social Studies'],
    '6': ['Math', 'Science', 'English', 'Social Studies'],
    '7': ['Math', 'Science', 'English', 'Social Studies'],
    '8': ['Math', 'Science', 'English', 'Social Studies', 'Computer Network'],
    '9': ['Math', 'Science', 'English', 'Social Studies'],
    '10': ['Math', 'Science', 'English', 'Social Studies'],
  };
  
  const topics = {
    'Math': ['Addition', 'Subtraction', 'Multiplication', 'Division', 'Fractions'],
    'Science': ['Plants', 'Animals', 'Human Body', 'Electricity', 'Magnets'],
    'English': ['Grammar', 'Vocabulary', 'Reading', 'Writing', 'Speaking'],
    'Social Studies': ['History', 'Geography', 'Civics', 'Economics', 'Culture'],
    'Computer Network': ['Introduction to HTML', 'Networking Basics', 'Internet Protocols'],
  };

  // Fetch video when user selects grade, subject, and topic
  const fetchVideo = async () => {
    if (!grade || !subject || !topic) return;
    
    setLoading(true);
    try {
      const { data, error } = await supabase
        .from('videos')
        .select('*')
        .eq('grade', grade)
        .eq('subject', subject)
        .eq('topic', topic)
        .single();
      
      if (error) throw error;
      
      if (data) {
        setVideo(data);
      } else {
        setVideo(null);
        toast({
          title: "Video not found",
          description: `No video available for Grade ${grade} ${subject} - ${topic}`,
          variant: "destructive"
        });
      }
    } catch (error) {
      console.error('Error fetching video:', error);
      toast({
        title: "Error",
        description: "Failed to fetch video. Please try again.",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  const handleStartClass = () => {
    if (grade && subject && topic) {
      fetchVideo().then(() => {
        setVideoStarted(true);
      });
    }
  };

  return (
    <div className="container mx-auto py-8">
      <h1 className="text-3xl font-bold mb-8 text-eduverse-primary">{t('resumeClass')}</h1>

      {!videoStarted ? (
        <Card className="w-full max-w-3xl mx-auto shadow-md">
          <CardContent className="p-6">
            <div className="space-y-6">
              <div>
                <label className="block text-sm font-medium mb-2">{t('selectGrade')}</label>
                <Select value={grade} onValueChange={setGrade}>
                  <SelectTrigger>
                    <SelectValue placeholder={t('selectGrade')} />
                  </SelectTrigger>
                  <SelectContent>
                    {grades.map((g) => (
                      <SelectItem key={g} value={g}>
                        {t('grade')} {g}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              {grade && (
                <div>
                  <label className="block text-sm font-medium mb-2">{t('selectSubject')}</label>
                  <Select value={subject} onValueChange={setSubject}>
                    <SelectTrigger>
                      <SelectValue placeholder={t('selectSubject')} />
                    </SelectTrigger>
                    <SelectContent>
                      {subjects[grade as keyof typeof subjects]?.map((s) => (
                        <SelectItem key={s} value={s}>
                          {s}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              )}

              {subject && (
                <div>
                  <label className="block text-sm font-medium mb-2">{t('selectTopic')}</label>
                  <Select value={topic} onValueChange={setTopic}>
                    <SelectTrigger>
                      <SelectValue placeholder={t('selectTopic')} />
                    </SelectTrigger>
                    <SelectContent>
                      {topics[subject as keyof typeof topics]?.map((tp) => (
                        <SelectItem key={tp} value={tp}>
                          {tp}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              )}

              <Button 
                onClick={handleStartClass} 
                disabled={!grade || !subject || !topic || loading}
                className="w-full bg-eduverse-primary hover:bg-eduverse-primary/90"
              >
                {loading ? (
                  <span className="flex items-center">
                    <span className="h-4 w-4 mr-2 animate-spin rounded-full border-2 border-white border-t-transparent"></span>
                    Loading...
                  </span>
                ) : (
                  <>
                    <PlayCircle className="mr-2" size={18} />
                    {t('startClass')}
                  </>
                )}
              </Button>
            </div>
          </CardContent>
        </Card>
      ) : (
        <div className="w-full max-w-4xl mx-auto">
          {video ? (
            <div className="space-y-4">
              <h2 className="text-2xl font-semibold">{video.title}</h2>
              {video.description && (
                <p className="text-gray-600">{video.description}</p>
              )}
              <div className="aspect-video rounded-lg overflow-hidden bg-black">
                <video 
                  controls 
                  className="w-full h-full"
                  src={video.video_url}
                >
                  Your browser does not support the video tag.
                </video>
              </div>
              <div className="text-sm text-gray-500">
                Grade {video.grade} {video.subject} - {video.topic}
              </div>
            </div>
          ) : (
            <div className="text-center py-10">
              <p className="text-lg text-gray-600">
                No video found for Grade {grade} {subject} - {topic}
              </p>
            </div>
          )}
          <div className="flex justify-between mt-4">
            <Button 
              variant="outline" 
              onClick={() => {
                setVideoStarted(false);
                setVideo(null);
              }}
            >
              Back to Selection
            </Button>
          </div>
        </div>
      )}
    </div>
  );
};

export default ResumeClass;
